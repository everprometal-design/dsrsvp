# DS RSVP - lectura rápida para DS / DSi

Lee libros **EPUB** (y `.txt`) mostrándolos **una palabra a la vez**, con la letra de enfoque en rojo y las **palabras por minuto** visibles (arriba a la izquierda). Se hace pausa más larga en puntos y comas.

## Cómo compilarlo

**Opción A: GitHub (sin instalar nada)**
1. Crea un repositorio en GitHub y sube todo el contenido de esta carpeta (incluida `.github`).
2. Pestaña **Actions** → "Compilar DS RSVP" → Run workflow.
3. Descarga `dsrsvp.nds` de "Artifacts".

**Opción B: en tu PC con devkitPro**
1. Instala devkitPro (devkitARM, libnds, libfat).
2. En esta carpeta: `make` → genera `dsrsvp.nds`.

## Instalación en el DSi

1. Copia `dsrsvp.nds` a la SD (por ejemplo `/roms/nds/`).
2. Crea la carpeta `/books` en la SD y copia ahí tus libros **.epub** (o .txt).
3. Ábrelo desde TWiLight Menu++ (o tu menú).

Los EPUB se leen directamente (texto de todos los capítulos, sin imágenes). Acentos y ñ funcionan. No se soportan EPUB con DRM.

## Controles

| Botón | Acción |
|---|---|
| A / tocar pantalla | leer / pausa |
| Arriba / Abajo | WPM ±10 |
| X / Y | WPM ±50 |
| Izquierda / Derecha | palabra anterior / siguiente |
| L / R | frase anterior / siguiente |
| B | volver al menú (guarda progreso) |

El progreso y los WPM se guardan por libro en `/books/<libro>.pos`.

## Notas

- Rango de velocidad: 60 a 1500 WPM (empieza en 300).
- En un DS/DS Lite viejo (4 MB de RAM) los libros muy grandes se recortan; en DSi caben hasta 3 MB de texto.
- Abrir un EPUB grande puede tardar unos segundos (descomprime todos los capítulos).
- La fuente se regenera con `python3 tools/gen_font.py source/font.h` (requiere Pillow).
