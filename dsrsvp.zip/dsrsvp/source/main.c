/*
 * DS RSVP - lector de lectura rapida para Nintendo DS / DSi
 * Muestra un libro .txt palabra por palabra, con WPM ajustable
 * y la letra de enfoque (ORP) en rojo.
 *
 * Libros: carpeta books de la SD, archivos .epub o .txt
 * Progreso: se guarda junto al libro como <libro>.txt.pos
 */
#include <nds.h>
#include <fat.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <dirent.h>
#include <sys/stat.h>

#include "font.h"
#include "epub.h"

#define SW 256
#define SH 192
#define FB ((u16 *)VRAM_A)

#define MAXBOOKS 96
#define NAMELEN 128
#define MAXCH 19
#define MAXBUF (3 * 1024 * 1024)
#define WPM_MIN 60
#define WPM_MAX 1500
#define WPM_DEF 300
#define FRAMES_PER_MS 0.0598261f

typedef struct {
    int w, h;
    const unsigned char *d;
} Font;

static const Font BIG = {BIG_W, BIG_H, font_big};
static const Font SMALL = {SM_W, SM_H, font_sm};

/* ------------------------------------------------------------ dibujo */

static void fill_rect(int x, int y, int w, int h, u16 col) {
    for (int j = 0; j < h; j++) {
        int yy = y + j;
        if (yy < 0 || yy >= SH) continue;
        for (int i = 0; i < w; i++) {
            int xx = x + i;
            if (xx < 0 || xx >= SW) continue;
            FB[yy * SW + xx] = col;
        }
    }
}

static void clear_screen(void) {
    dmaFillHalfWords(RGB15(0, 0, 0), FB, SW * SH * 2);
}

static void draw_char(const Font *f, int x, int y, unsigned char c, int fr, int fg, int fb) {
    if (c < 32) c = '?';
    const unsigned char *g = f->d + (size_t)(c - 32) * f->w * f->h;
    for (int j = 0; j < f->h; j++) {
        int yy = y + j;
        if (yy < 0 || yy >= SH) continue;
        u16 *row = FB + yy * SW;
        for (int i = 0; i < f->w; i++) {
            int xx = x + i;
            if (xx < 0 || xx >= SW) continue;
            int a = g[j * f->w + i];
            if (!a) continue;
            row[xx] = RGB15((fr * a) >> 11, (fg * a) >> 11, (fb * a) >> 11);
        }
    }
}

static void draw_text(const Font *f, int x, int y, const char *s, int r, int g, int b) {
    for (; *s; s++, x += f->w) draw_char(f, x, y, (unsigned char)*s, r, g, b);
}

static void draw_text_centered(const Font *f, int y, const char *s, int r, int g, int b) {
    int n = (int)strlen(s);
    draw_text(f, (SW - n * f->w) / 2, y, s, r, g, b);
}

static int orp_index(int n) {
    if (n <= 1) return 0;
    if (n <= 5) return 1;
    if (n <= 9) return 2;
    if (n <= 13) return 3;
    return 4;
}

/* ------------------------------------------------------------ libro */

static unsigned char *buf = NULL;
static u32 blen = 0;

static int is_ws(unsigned char c) {
    return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == 0x0B || c == 0x0C;
}

/* decodifica un caracter (UTF-8, o Latin-1 si no es UTF-8 valido) a Latin-1.
   devuelve el offset siguiente; *out = 0 si debe omitirse */
static u32 decode_one(u32 q, u32 end, unsigned char *out) {
    unsigned char b = buf[q];
    u32 cp;
    u32 nx;
    if (b < 0x80) {
        cp = b;
        nx = q + 1;
    } else if ((b & 0xE0) == 0xC0 && q + 1 < end && (buf[q + 1] & 0xC0) == 0x80) {
        cp = ((b & 0x1F) << 6) | (buf[q + 1] & 0x3F);
        nx = q + 2;
    } else if ((b & 0xF0) == 0xE0 && q + 2 < end && (buf[q + 1] & 0xC0) == 0x80 &&
               (buf[q + 2] & 0xC0) == 0x80) {
        cp = ((b & 0x0F) << 12) | ((buf[q + 1] & 0x3F) << 6) | (buf[q + 2] & 0x3F);
        nx = q + 3;
    } else if ((b & 0xF8) == 0xF0 && q + 3 < end && (buf[q + 1] & 0xC0) == 0x80 &&
               (buf[q + 2] & 0xC0) == 0x80 && (buf[q + 3] & 0xC0) == 0x80) {
        cp = 0x10000; /* emoji etc. */
        nx = q + 4;
    } else {
        cp = b; /* byte Latin-1 suelto */
        nx = q + 1;
    }

    unsigned char r;
    if (cp >= 32 && cp < 127) r = (unsigned char)cp;
    else if (cp >= 0xA0 && cp <= 0xFF) r = (unsigned char)cp;
    else if (cp == 0x2018 || cp == 0x2019 || cp == 0x201A) r = '\'';
    else if (cp == 0x201C || cp == 0x201D || cp == 0x201E) r = '"';
    else if (cp == 0x2013 || cp == 0x2014 || cp == 0x2212) r = '-';
    else if (cp == 0x2026) r = '.';
    else if (cp == 0x2022) r = '*';
    else if (cp == 0x20AC) r = 'E';
    else if (cp == 0xFEFF || cp == 0x200B || cp == 0xAD) r = 0;
    else if (cp < 32 || (cp >= 0x7F && cp < 0xA0)) r = 0;
    else r = '?';
    *out = r;
    return nx;
}

/* lee la siguiente palabra a 'out' (Latin-1). devuelve su longitud, 0 = fin */
static int read_word(u32 *pp, char *out) {
    u32 p = *pp;
    for (;;) {
        while (p < blen && is_ws(buf[p])) p++;
        if (p >= blen) {
            *pp = p;
            out[0] = 0;
            return 0;
        }
        u32 end = p;
        while (end < blen && !is_ws(buf[end])) end++;
        int n = 0;
        u32 q = p;
        while (q < end && n < MAXCH) {
            unsigned char ch;
            q = decode_one(q, end, &ch);
            if (ch) out[n++] = (char)ch;
        }
        p = q; /* si la palabra era larguisima, el resto sale como otro trozo */
        if (n > 0) {
            out[n] = 0;
            *pp = p;
            return n;
        }
    }
}

static void back1(u32 *pp) {
    u32 p = *pp;
    while (p > 0 && is_ws(buf[p - 1])) p--;
    while (p > 0 && !is_ws(buf[p - 1])) p--;
    *pp = p;
}

static int sentence_end_char(unsigned char c) { return c == '.' || c == '!' || c == '?'; }

static int word_ends_sentence(const char *w, int n) {
    int e = n;
    while (e > 0 && (w[e - 1] == '"' || w[e - 1] == '\'' || w[e - 1] == ')' || (unsigned char)w[e - 1] == 0xBB)) e--;
    return e > 0 && sentence_end_char((unsigned char)w[e - 1]);
}

static void back_sentence(u32 *pp) {
    u32 p = *pp;
    back1(&p); /* inicio de la palabra mostrada */
    back1(&p); /* la anterior */
    int guard = 0;
    while (p > 0 && guard++ < 400) {
        u32 q = p;
        while (q > 0 && is_ws(buf[q - 1])) q--;
        if (q == 0) {
            p = 0;
            break;
        }
        u32 t = q;
        while (t > 0 && (buf[t - 1] == '"' || buf[t - 1] == '\'' || buf[t - 1] == ')')) t--;
        if (t > 0 && sentence_end_char(buf[t - 1])) break;
        back1(&p);
    }
    *pp = p;
}

static void fwd_sentence(u32 *pp) {
    char w[32];
    int guard = 0;
    while (guard++ < 400) {
        int n = read_word(pp, w);
        if (!n || word_ends_sentence(w, n)) break;
    }
}

static float pause_mult(const char *w, int n) {
    int e = n;
    while (e > 0 && (w[e - 1] == '"' || w[e - 1] == '\'' || w[e - 1] == ')' || (unsigned char)w[e - 1] == 0xBB)) e--;
    float m = 1.0f;
    if (e > 0) {
        char c = w[e - 1];
        if (c == '.' || c == '!' || c == '?') m = 2.2f;
        else if (c == ',' || c == ';' || c == ':') m = 1.6f;
    }
    if (n >= 13) m *= 1.5f;
    else if (n >= 9) m *= 1.25f;
    return m;
}

/* ------------------------------------------------------------ pantalla superior */

static void render(const char *w, int n, int wpm, int playing, u32 pos) {
    char tmp[32];
    clear_screen();

    /* WPM arriba a la izquierda */
    snprintf(tmp, sizeof tmp, "%d wpm", wpm);
    draw_text(&SMALL, 6, 3, tmp, 150, 150, 150);

    /* marcas guia */
    fill_rect(127, 56, 2, 10, RGB15(12, 12, 12));
    fill_rect(127, 128, 2, 10, RGB15(12, 12, 12));

    if (n > 0) {
        const Font *f = &BIG;
        int o = orp_index(n);
        int x0 = SW / 2 - (o * f->w + f->w / 2);
        if (x0 < 0 || x0 + n * f->w > SW) {
            f = &SMALL;
            x0 = SW / 2 - (o * f->w + f->w / 2);
            if (x0 < 0 || x0 + n * f->w > SW) x0 = (SW - n * f->w) / 2;
        }
        int y0 = (SH - f->h) / 2 + 1;
        for (int i = 0; i < n; i++) {
            if (i == o) draw_char(f, x0 + i * f->w, y0, (unsigned char)w[i], 255, 60, 60);
            else draw_char(f, x0 + i * f->w, y0, (unsigned char)w[i], 240, 240, 240);
        }
    }

    if (!playing) draw_text_centered(&SMALL, 150, "PAUSA", 110, 110, 110);

    /* barra de progreso */
    fill_rect(0, 184, SW, 6, RGB15(5, 5, 5));
    if (blen > 0) {
        u32 pw = (u32)(((u64)pos * SW) / blen);
        fill_rect(0, 184, (int)pw, 6, RGB15(25, 7, 7));
    }
}

static void message_top(const char *l1, const char *l2) {
    clear_screen();
    draw_text_centered(&BIG, 60, l1, 240, 240, 240);
    if (l2) draw_text_centered(&SMALL, 120, l2, 150, 150, 150);
}

/* ------------------------------------------------------------ progreso en SD */

static void pos_path(const char *name, char *out, size_t sz) {
    snprintf(out, sz, "/books/%s.pos", name);
}

static void save_progress(const char *name, u32 pos, int wpm) {
    char path[200];
    pos_path(name, path, sizeof path);
    FILE *f = fopen(path, "w");
    if (!f) return;
    fprintf(f, "%lu %d\n", (unsigned long)pos, wpm);
    fclose(f);
}

static void load_progress(const char *name, u32 *pos, int *wpm) {
    char path[200];
    unsigned long p = 0;
    int w = WPM_DEF;
    pos_path(name, path, sizeof path);
    FILE *f = fopen(path, "r");
    if (f) {
        if (fscanf(f, "%lu %d", &p, &w) < 1) p = 0;
        fclose(f);
    }
    if (w < WPM_MIN || w > WPM_MAX) w = WPM_DEF;
    *pos = (u32)p;
    *wpm = w;
}

/* ------------------------------------------------------------ lectura */

static void info_bottom(const char *name, int wpm, int playing, u32 pos, int truncated) {
    char shown[32];
    snprintf(shown, sizeof shown, "%.30s", name);
    int pct = blen ? (int)(((u64)pos * 100) / blen) : 0;
    printf("\x1b[2J\x1b[0;0H");
    printf(" DS RSVP\n %s\n\n", shown);
    printf(" VELOCIDAD: %d WPM\n", wpm);
    printf(" PROGRESO:  %d%%\n", pct);
    printf(" ESTADO:    %s\n", playing ? "LEYENDO" : "PAUSA");
    if (truncated) printf(" (libro recortado a %d KB)\n", (int)(blen / 1024));
    printf("\n A / tocar : leer / pausa\n");
    printf(" Arriba/Abajo : WPM +-10\n");
    printf(" X / Y : WPM +-50\n");
    printf(" Izq/Der : palabra -/+\n");
    printf(" L / R : frase -/+\n");
    printf(" B : volver al menu\n");
}

static int has_ext(const char *name, const char *ext) {
    size_t l = strlen(name), e = strlen(ext);
    return l > e && strcasecmp(name + l - e, ext) == 0;
}

static int load_book(const char *name, int *truncated) {
    char path[200];
    snprintf(path, sizeof path, "/books/%s", name);
    *truncated = 0;

    if (has_ext(name, ".epub")) {
        uint32_t len = 0;
        int ok = epub_load(path, &buf, &len, MAXBUF, truncated);
        blen = len;
        return ok && blen > 0;
    }

    FILE *f = fopen(path, "rb");
    if (!f) return 0;
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (size <= 0) {
        fclose(f);
        return 0;
    }
    u32 want = (size > MAXBUF) ? MAXBUF : (u32)size;
    while (!(buf = (unsigned char *)malloc(want)) && want > 65536) want /= 2;
    if (!buf) {
        fclose(f);
        return 0;
    }
    blen = (u32)fread(buf, 1, want, f);
    fclose(f);
    *truncated = (blen < (u32)size);
    return blen > 0;
}

static void read_book(const char *name) {
    int truncated = 0;
    message_top("Cargando...", NULL);
    printf("\x1b[2J\x1b[0;0H Cargando libro...\n");
    if (!load_book(name, &truncated)) {
        message_top("Error", "No se pudo abrir el libro");
        for (int i = 0; i < 120; i++) swiWaitForVBlank();
        return;
    }

    u32 pos;
    int wpm;
    load_progress(name, &pos, &wpm);
    if (pos >= blen) pos = 0;

    int playing = 0;
    float wait = 0.0f;
    int tick = 0;
    char w[32];
    int n;

    /* primera palabra */
    n = read_word(&pos, w);
    render(w, n, wpm, playing, pos);
    info_bottom(name, wpm, playing, pos, truncated);

    keysSetRepeat(20, 4);

    for (;;) {
        swiWaitForVBlank();
        scanKeys();
        u32 down = keysDown();
        u32 rep = keysDownRepeat();
        int changed = 0;   /* hay que redibujar la palabra actual */
        int newword = 0;   /* hay que leer y mostrar otra palabra */

        if (down & KEY_B) break;

        if (down & (KEY_A | KEY_TOUCH)) {
            playing = !playing;
            wait = 0.0f;
            if (!playing) save_progress(name, pos, wpm);
            changed = 1;
            info_bottom(name, wpm, playing, pos, truncated);
        }

        if (rep & KEY_UP) { wpm += 10; changed = 1; }
        if (rep & KEY_DOWN) { wpm -= 10; changed = 1; }
        if (rep & KEY_X) { wpm += 50; changed = 1; }
        if (rep & KEY_Y) { wpm -= 50; changed = 1; }
        if (wpm < WPM_MIN) wpm = WPM_MIN;
        if (wpm > WPM_MAX) wpm = WPM_MAX;

        if (rep & KEY_LEFT) {
            back1(&pos);
            back1(&pos);
            newword = 1;
        }
        if (rep & KEY_RIGHT) newword = 1;
        if (rep & KEY_L) {
            back_sentence(&pos);
            newword = 1;
        }
        if (rep & KEY_R) {
            fwd_sentence(&pos);
            newword = 1;
        }

        if (!newword && playing) {
            if (wait <= 0.0f) {
                newword = 1;
                wait += 0.0f; /* la duracion se suma abajo */
            }
        }

        if (newword) {
            n = read_word(&pos, w);
            if (n == 0) {
                playing = 0;
                strcpy(w, "FIN");
                n = 3;
                pos = blen;
                save_progress(name, 0, wpm);
                info_bottom(name, wpm, playing, pos, truncated);
            } else if (playing) {
                float ms = 60000.0f / (float)wpm * pause_mult(w, n);
                wait += ms * FRAMES_PER_MS;
            }
            changed = 1;
        }

        if (playing) wait -= 1.0f;

        if (changed) render(w, n, wpm, playing, pos);

        if (++tick >= 30 || (changed && !playing)) {
            tick = 0;
            info_bottom(name, wpm, playing, pos, truncated);
        }
    }

    save_progress(name, (n == 0 || pos >= blen) ? 0 : pos, wpm);
    free(buf);
    buf = NULL;
    blen = 0;
}

/* ------------------------------------------------------------ menu */

static char names[MAXBOOKS][NAMELEN];
static int nbooks = 0;

static int cmp_names(const void *a, const void *b) { return strcasecmp((const char *)a, (const char *)b); }

static void scan_books(void) {
    nbooks = 0;
    mkdir("/books", 0777);
    DIR *d = opendir("/books");
    if (!d) return;
    struct dirent *e;
    while ((e = readdir(d)) != NULL && nbooks < MAXBOOKS) {
        size_t l = strlen(e->d_name);
        if (l < 5 || l >= NAMELEN - 8) continue;
        if (!has_ext(e->d_name, ".txt") && !has_ext(e->d_name, ".epub")) continue;
        if (e->d_name[0] == '.') continue;
        strcpy(names[nbooks++], e->d_name);
    }
    closedir(d);
    qsort(names, nbooks, NAMELEN, cmp_names);
}

static void draw_menu(int sel, int top) {
    printf("\x1b[2J\x1b[0;0H");
    printf(" DS RSVP - lectura rapida\n");
    printf(" ------------------------\n");
    if (nbooks == 0) {
        printf("\n No hay libros.\n\n");
        printf(" Copia archivos .epub o .txt\n a la carpeta /books de la SD\n y reinicia el programa.\n");
        return;
    }
    for (int i = 0; i < 18 && top + i < nbooks; i++) {
        int k = top + i;
        printf("%c%.30s\n", k == sel ? '>' : ' ', names[k]);
    }
    printf("\n A: abrir   Arriba/Abajo: elegir\n");
}

int main(void) {
    videoSetMode(MODE_FB0);
    vramSetBankA(VRAM_A_LCD);
    consoleDemoInit();
    keysSetRepeat(20, 4);

    message_top("DS RSVP", "Lectura rapida");

    if (!fatInitDefault()) {
        printf("\n No se pudo acceder a la SD.\n\n Abre el programa desde\n TWiLight Menu++ o con un\n flashcard con DLDI.\n");
        for (;;) swiWaitForVBlank();
    }

    scan_books();
    int sel = 0, top = 0;
    draw_menu(sel, top);

    for (;;) {
        swiWaitForVBlank();
        scanKeys();
        u32 down = keysDown();
        u32 rep = keysDownRepeat();
        int redraw = 0;

        if (nbooks > 0) {
            if (rep & KEY_DOWN) {
                if (sel < nbooks - 1) sel++;
                redraw = 1;
            }
            if (rep & KEY_UP) {
                if (sel > 0) sel--;
                redraw = 1;
            }
            if (sel < top) top = sel;
            if (sel >= top + 18) top = sel - 17;

            if (down & KEY_A) {
                read_book(names[sel]);
                message_top("DS RSVP", "Lectura rapida");
                redraw = 1;
            }
        }
        if (redraw) draw_menu(sel, top);
    }
    return 0;
}
