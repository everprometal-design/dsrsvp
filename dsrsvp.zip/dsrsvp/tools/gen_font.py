#!/usr/bin/env python3
"""Genera source/font.h: dos fuentes monoespaciadas Latin-1 (32..255), 8 bits de alfa por pixel."""
import sys
from PIL import Image, ImageDraw, ImageFont

FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"


def gen(name, size, w):
    f = ImageFont.truetype(FONT, size)
    asc, desc = f.getmetrics()
    h = asc + desc + 1
    data = bytearray()
    for c in range(32, 256):
        img = Image.new("L", (w, h), 0)
        d = ImageDraw.Draw(img)
        ch = chr(c)
        bw = d.textlength(ch, font=f)
        d.text(((w - bw) / 2.0, asc), ch, font=f, fill=255, anchor="ls")
        data += img.tobytes()
    lines = []
    lines.append(f"#define {name.upper()}_W {w}")
    lines.append(f"#define {name.upper()}_H {h}")
    lines.append(f"static const unsigned char font_{name}[] __attribute__((aligned(4))) = {{")
    row = []
    for i, b in enumerate(data):
        row.append(str(b))
        if len(row) == 32:
            lines.append(",".join(row) + ",")
            row = []
    if row:
        lines.append(",".join(row))
    lines.append("};")
    return "\n".join(lines), h


def main(out):
    big, hb = gen("big", 32, 20)
    small, hs = gen("sm", 21, 13)
    with open(out, "w") as fh:
        fh.write("/* generado por tools/gen_font.py - no editar */\n")
        fh.write(big + "\n" + small + "\n")
    print("big h =", hb, "small h =", hs)


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "source/font.h")
