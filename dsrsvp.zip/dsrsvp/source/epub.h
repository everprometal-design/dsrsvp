#ifndef EPUB_H
#define EPUB_H

#include <stdint.h>

/* Lee un .epub y devuelve todo el texto del libro (UTF-8, sin etiquetas)
   en un buffer malloc'ed. maxlen limita el tamano. Devuelve 1 si hubo exito. */
int epub_load(const char *path, unsigned char **out, uint32_t *outlen, uint32_t maxlen, int *truncated);

#endif
