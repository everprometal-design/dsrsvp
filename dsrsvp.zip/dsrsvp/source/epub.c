/*
 * Lector de EPUB minimo: zip + inflate (estilo puff) + extraccion de texto.
 */
#include "epub.h"

#include <ctype.h>
#include <setjmp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

/* ================================================================= inflate */

struct st {
    const uint8_t *in;
    uint32_t inlen, incnt;
    uint8_t *out;
    uint32_t outlen, outcnt;
    uint32_t bitbuf;
    int bitcnt;
    jmp_buf jb;
};

struct huff {
    int16_t count[16];
    int16_t symbol[288];
};

static int bits(struct st *s, int need) {
    uint32_t val = s->bitbuf;
    while (s->bitcnt < need) {
        if (s->incnt >= s->inlen) longjmp(s->jb, 1);
        val |= (uint32_t)s->in[s->incnt++] << s->bitcnt;
        s->bitcnt += 8;
    }
    s->bitbuf = val >> need;
    s->bitcnt -= need;
    return (int)(val & ((1u << need) - 1));
}

static int decode(struct st *s, const struct huff *h) {
    int code = 0, first = 0, index = 0;
    for (int len = 1; len <= 15; len++) {
        code |= bits(s, 1);
        int count = h->count[len];
        if (code - count < first) return h->symbol[index + (code - first)];
        index += count;
        first += count;
        first <<= 1;
        code <<= 1;
    }
    longjmp(s->jb, 1);
    return -1;
}

static int construct(struct huff *h, const int16_t *length, int n) {
    int16_t offs[16];
    for (int len = 0; len <= 15; len++) h->count[len] = 0;
    for (int sym = 0; sym < n; sym++) h->count[length[sym]]++;
    if (h->count[0] == n) return 0;
    int left = 1;
    for (int len = 1; len <= 15; len++) {
        left <<= 1;
        left -= h->count[len];
        if (left < 0) return left;
    }
    offs[1] = 0;
    for (int len = 1; len < 15; len++) offs[len + 1] = offs[len] + h->count[len];
    for (int sym = 0; sym < n; sym++)
        if (length[sym] != 0) h->symbol[offs[length[sym]]++] = (int16_t)sym;
    return left;
}

static const int16_t LENS[29] = {3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258};
static const int16_t LEXT[29] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0};
static const int16_t DISTS[30] = {1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577};
static const int16_t DEXT[30] = {0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13};

static void codes(struct st *s, const struct huff *lencode, const struct huff *distcode) {
    int symbol;
    do {
        symbol = decode(s, lencode);
        if (symbol < 256) {
            if (s->outcnt >= s->outlen) longjmp(s->jb, 1);
            s->out[s->outcnt++] = (uint8_t)symbol;
        } else if (symbol > 256) {
            symbol -= 257;
            if (symbol >= 29) longjmp(s->jb, 1);
            int len = LENS[symbol] + bits(s, LEXT[symbol]);
            symbol = decode(s, distcode);
            if (symbol >= 30) longjmp(s->jb, 1);
            uint32_t dist = (uint32_t)(DISTS[symbol] + bits(s, DEXT[symbol]));
            if (dist > s->outcnt) longjmp(s->jb, 1);
            if (s->outcnt + (uint32_t)len > s->outlen) longjmp(s->jb, 1);
            while (len--) {
                s->out[s->outcnt] = s->out[s->outcnt - dist];
                s->outcnt++;
            }
        }
    } while (symbol != 256);
}

static void stored(struct st *s) {
    s->bitbuf = 0;
    s->bitcnt = 0;
    if (s->incnt + 4 > s->inlen) longjmp(s->jb, 1);
    uint32_t len = s->in[s->incnt] | (s->in[s->incnt + 1] << 8);
    uint32_t nlen = s->in[s->incnt + 2] | (s->in[s->incnt + 3] << 8);
    if (len != (~nlen & 0xFFFF)) longjmp(s->jb, 1);
    s->incnt += 4;
    if (s->incnt + len > s->inlen) longjmp(s->jb, 1);
    if (s->outcnt + len > s->outlen) longjmp(s->jb, 1);
    memcpy(s->out + s->outcnt, s->in + s->incnt, len);
    s->incnt += len;
    s->outcnt += len;
}

static void fixed(struct st *s) {
    int16_t lengths[288];
    struct huff lencode, distcode;
    int sym;
    for (sym = 0; sym < 144; sym++) lengths[sym] = 8;
    for (; sym < 256; sym++) lengths[sym] = 9;
    for (; sym < 280; sym++) lengths[sym] = 7;
    for (; sym < 288; sym++) lengths[sym] = 8;
    construct(&lencode, lengths, 288);
    for (sym = 0; sym < 30; sym++) lengths[sym] = 5;
    construct(&distcode, lengths, 30);
    codes(s, &lencode, &distcode);
}

static void dynamic(struct st *s) {
    static const int16_t order[19] = {16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15};
    int16_t lengths[320];
    struct huff lencode, distcode;
    int nlen = bits(s, 5) + 257;
    int ndist = bits(s, 5) + 1;
    int ncode = bits(s, 4) + 4;
    if (nlen > 286 || ndist > 30) longjmp(s->jb, 1);
    int index;
    for (index = 0; index < ncode; index++) lengths[order[index]] = (int16_t)bits(s, 3);
    for (; index < 19; index++) lengths[order[index]] = 0;
    if (construct(&lencode, lengths, 19) != 0) longjmp(s->jb, 1);
    index = 0;
    while (index < nlen + ndist) {
        int symbol = decode(s, &lencode);
        if (symbol < 16) {
            lengths[index++] = (int16_t)symbol;
        } else {
            int len = 0;
            if (symbol == 16) {
                if (index == 0) longjmp(s->jb, 1);
                len = lengths[index - 1];
                symbol = 3 + bits(s, 2);
            } else if (symbol == 17) {
                symbol = 3 + bits(s, 3);
            } else {
                symbol = 11 + bits(s, 7);
            }
            if (index + symbol > nlen + ndist) longjmp(s->jb, 1);
            while (symbol--) lengths[index++] = (int16_t)len;
        }
    }
    if (lengths[256] == 0) longjmp(s->jb, 1);
    if (construct(&lencode, lengths, nlen) < 0) longjmp(s->jb, 1);
    if (construct(&distcode, lengths + nlen, ndist) < 0) longjmp(s->jb, 1);
    codes(s, &lencode, &distcode);
}

/* devuelve 1 si ok */
static int inflate_buf(const uint8_t *in, uint32_t inlen, uint8_t *out, uint32_t outlen) {
    struct st s;
    s.in = in;
    s.inlen = inlen;
    s.incnt = 0;
    s.out = out;
    s.outlen = outlen;
    s.outcnt = 0;
    s.bitbuf = 0;
    s.bitcnt = 0;
    if (setjmp(s.jb)) return 0;
    int last;
    do {
        last = bits(&s, 1);
        int type = bits(&s, 2);
        if (type == 0) stored(&s);
        else if (type == 1) fixed(&s);
        else if (type == 2) dynamic(&s);
        else return 0;
    } while (!last);
    return s.outcnt == outlen;
}

/* ================================================================= zip */

typedef struct {
    const char *name;
    int nlen;
    uint32_t method, csize, usize, off;
} ZEnt;

typedef struct {
    FILE *f;
    uint8_t *cd;
    ZEnt *ents;
    int n;
} Zip;

static uint32_t le16(const uint8_t *p) { return p[0] | (p[1] << 8); }
static uint32_t le32(const uint8_t *p) { return p[0] | (p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24); }

static void zip_close(Zip *z) {
    if (z->f) fclose(z->f);
    free(z->cd);
    free(z->ents);
    memset(z, 0, sizeof *z);
}

static int zip_open(Zip *z, const char *path) {
    memset(z, 0, sizeof *z);
    z->f = fopen(path, "rb");
    if (!z->f) return 0;
    fseek(z->f, 0, SEEK_END);
    long size = ftell(z->f);
    if (size < 22) goto fail;
    long tail = size < 65557 ? size : 65557;
    uint8_t *t = (uint8_t *)malloc((size_t)tail);
    if (!t) goto fail;
    fseek(z->f, size - tail, SEEK_SET);
    if (fread(t, 1, (size_t)tail, z->f) != (size_t)tail) {
        free(t);
        goto fail;
    }
    long e = -1;
    for (long i = tail - 22; i >= 0; i--) {
        if (t[i] == 'P' && t[i + 1] == 'K' && t[i + 2] == 5 && t[i + 3] == 6) {
            e = i;
            break;
        }
    }
    if (e < 0) {
        free(t);
        goto fail;
    }
    int n = (int)le16(t + e + 10);
    uint32_t cdsize = le32(t + e + 12);
    uint32_t cdoff = le32(t + e + 16);
    free(t);
    if (n <= 0 || cdsize == 0 || cdsize > 4 * 1024 * 1024) goto fail;
    z->cd = (uint8_t *)malloc(cdsize);
    z->ents = (ZEnt *)malloc(sizeof(ZEnt) * (size_t)n);
    if (!z->cd || !z->ents) goto fail;
    fseek(z->f, (long)cdoff, SEEK_SET);
    if (fread(z->cd, 1, cdsize, z->f) != cdsize) goto fail;
    uint32_t pos = 0;
    int cnt = 0;
    for (int i = 0; i < n; i++) {
        if (pos + 46 > cdsize || le32(z->cd + pos) != 0x02014b50) break;
        const uint8_t *c = z->cd + pos;
        ZEnt *en = &z->ents[cnt++];
        en->method = le16(c + 10);
        en->csize = le32(c + 20);
        en->usize = le32(c + 24);
        en->nlen = (int)le16(c + 28);
        uint32_t elen = le16(c + 30), clen = le16(c + 32);
        en->off = le32(c + 42);
        en->name = (const char *)(c + 46);
        pos += 46 + (uint32_t)en->nlen + elen + clen;
        if (pos > cdsize) {
            cnt--;
            break;
        }
    }
    z->n = cnt;
    return cnt > 0;
fail:
    zip_close(z);
    return 0;
}

static ZEnt *zip_find(Zip *z, const char *name) {
    int nl = (int)strlen(name);
    for (int i = 0; i < z->n; i++)
        if (z->ents[i].nlen == nl && memcmp(z->ents[i].name, name, (size_t)nl) == 0) return &z->ents[i];
    for (int i = 0; i < z->n; i++)
        if (z->ents[i].nlen == nl && strncasecmp(z->ents[i].name, name, (size_t)nl) == 0) return &z->ents[i];
    return NULL;
}

/* devuelve buffer malloc'ed con NUL final, tamano en *size */
static uint8_t *zip_read(Zip *z, const ZEnt *e, uint32_t *size) {
    if (e->usize > 6 * 1024 * 1024 || e->csize > 6 * 1024 * 1024) return NULL;
    uint8_t h[30];
    fseek(z->f, (long)e->off, SEEK_SET);
    if (fread(h, 1, 30, z->f) != 30 || le32(h) != 0x04034b50) return NULL;
    long data = (long)e->off + 30 + (long)le16(h + 26) + (long)le16(h + 28);
    fseek(z->f, data, SEEK_SET);
    uint8_t *comp = (uint8_t *)malloc(e->csize ? e->csize : 1);
    if (!comp) return NULL;
    if (fread(comp, 1, e->csize, z->f) != e->csize) {
        free(comp);
        return NULL;
    }
    uint8_t *out = (uint8_t *)malloc((size_t)e->usize + 1);
    if (!out) {
        free(comp);
        return NULL;
    }
    int ok;
    if (e->method == 0) {
        ok = (e->csize == e->usize);
        if (ok) memcpy(out, comp, e->usize);
    } else if (e->method == 8) {
        ok = inflate_buf(comp, e->csize, out, e->usize);
    } else {
        ok = 0;
    }
    free(comp);
    if (!ok) {
        free(out);
        return NULL;
    }
    out[e->usize] = 0;
    *size = e->usize;
    return out;
}

/* ================================================================= XML simple */

/* siguiente etiqueta: t apunta al contenido tras '<' y tl es su largo (sin '>') */
static int next_tag(const char *x, uint32_t n, uint32_t *pos, const char **t, int *tl) {
    uint32_t i = *pos;
    for (;;) {
        while (i < n && x[i] != '<') i++;
        if (i >= n) return 0;
        if (i + 1 < n && (x[i + 1] == '?' || x[i + 1] == '!')) {
            if (i + 3 < n && x[i + 1] == '!' && x[i + 2] == '-' && x[i + 3] == '-') {
                i += 4;
                while (i + 2 < n && !(x[i] == '-' && x[i + 1] == '-' && x[i + 2] == '>')) i++;
                i += 3;
            } else {
                while (i < n && x[i] != '>') i++;
                i++;
            }
            continue;
        }
        break;
    }
    uint32_t s = i + 1, e = s;
    while (e < n && x[e] != '>') e++;
    *t = x + s;
    *tl = (int)(e - s);
    *pos = e + 1;
    return 1;
}

/* nombre local de la etiqueta en minusculas ("opf:item" -> "item"; "/p" -> "/p") */
static void tag_name(const char *t, int tl, char *out, int osz) {
    int i = 0, k = 0;
    if (i < tl && t[i] == '/') out[k++] = t[i++];
    int start = k;
    while (i < tl && !isspace((unsigned char)t[i]) && t[i] != '/' && k < osz - 1) {
        if (t[i] == ':') {
            k = start;
            i++;
            continue;
        }
        out[k++] = (char)tolower((unsigned char)t[i++]);
    }
    out[k] = 0;
}

static int attr(const char *t, int tl, const char *name, char *out, int osz) {
    int nl = (int)strlen(name);
    for (int i = 1; i + nl < tl; i++) {
        if (!isspace((unsigned char)t[i - 1])) continue;
        if (strncasecmp(t + i, name, (size_t)nl) != 0) continue;
        int j = i + nl;
        while (j < tl && isspace((unsigned char)t[j])) j++;
        if (j >= tl || t[j] != '=') continue;
        j++;
        while (j < tl && isspace((unsigned char)t[j])) j++;
        if (j >= tl) continue;
        char q = t[j];
        if (q != '"' && q != '\'') continue;
        j++;
        int k = 0;
        while (j < tl && t[j] != q && k < osz - 1) out[k++] = t[j++];
        out[k] = 0;
        return 1;
    }
    return 0;
}

static int hexv(int c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

static void url_decode(char *s) {
    char *o = s;
    while (*s) {
        if (*s == '%' && hexv((unsigned char)s[1]) >= 0 && hexv((unsigned char)s[2]) >= 0) {
            *o++ = (char)(hexv((unsigned char)s[1]) * 16 + hexv((unsigned char)s[2]));
            s += 3;
        } else {
            *o++ = *s++;
        }
    }
    *o = 0;
}

/* une base_dir + href, quita #frag, decodifica %XX y normaliza ./ y ../ */
static void resolve(const char *base_dir, const char *href, char *out, size_t osz) {
    char tmp[320];
    snprintf(tmp, sizeof tmp, "%s%s", base_dir, href);
    char *q = strpbrk(tmp, "#?");
    if (q) *q = 0;
    url_decode(tmp);
    char *o = out;
    const char *p = tmp;
    while (*p) {
        const char *seg = p;
        while (*p && *p != '/') p++;
        size_t l = (size_t)(p - seg);
        if (*p == '/') p++;
        if (l == 0 || (l == 1 && seg[0] == '.')) continue;
        if (l == 2 && seg[0] == '.' && seg[1] == '.') {
            if (o > out) {
                o--;
                while (o > out && o[-1] != '/') o--;
            }
            continue;
        }
        if ((size_t)(o - out) + l + 2 >= osz) break;
        memcpy(o, seg, l);
        o += l;
        *o++ = '/';
    }
    if (o > out) o--;
    *o = 0;
}

/* ================================================================= HTML -> texto */

typedef struct {
    unsigned char *d;
    uint32_t n, cap, max;
    int trunc;
} Out;

static void out_put(Out *o, unsigned char c) {
    if (o->n >= o->max) {
        o->trunc = 1;
        return;
    }
    if (o->n >= o->cap) {
        uint32_t nc = o->cap ? o->cap + o->cap / 2 : 65536;
        if (nc > o->max) nc = o->max;
        unsigned char *nd = (unsigned char *)realloc(o->d, nc);
        if (!nd) {
            o->trunc = 1;
            o->max = o->n;
            return;
        }
        o->d = nd;
        o->cap = nc;
    }
    o->d[o->n++] = c;
}

static void put_cp(Out *o, uint32_t cp) {
    if (cp < 0x80) {
        out_put(o, (unsigned char)cp);
    } else if (cp < 0x800) {
        out_put(o, (unsigned char)(0xC0 | (cp >> 6)));
        out_put(o, (unsigned char)(0x80 | (cp & 0x3F)));
    } else if (cp < 0x10000) {
        out_put(o, (unsigned char)(0xE0 | (cp >> 12)));
        out_put(o, (unsigned char)(0x80 | ((cp >> 6) & 0x3F)));
        out_put(o, (unsigned char)(0x80 | (cp & 0x3F)));
    } else {
        out_put(o, (unsigned char)(0xF0 | (cp >> 18)));
        out_put(o, (unsigned char)(0x80 | ((cp >> 12) & 0x3F)));
        out_put(o, (unsigned char)(0x80 | ((cp >> 6) & 0x3F)));
        out_put(o, (unsigned char)(0x80 | (cp & 0x3F)));
    }
}

static uint32_t find_ci(const uint8_t *h, uint32_t n, uint32_t i, const char *pat) {
    size_t pl = strlen(pat);
    for (; i + pl <= n; i++)
        if (strncasecmp((const char *)h + i, pat, pl) == 0) return i;
    return n;
}

static int is_block(const char *name) {
    static const char *const blocks[] = {"p", "div", "br", "h1", "h2", "h3", "h4", "h5", "h6", "li", "tr", "blockquote",
                                         "section", "article", "hr", "table", "ul", "ol", "pre", "dt", "dd", "title", "body"};
    const char *nm = name[0] == '/' ? name + 1 : name;
    for (size_t k = 0; k < sizeof blocks / sizeof blocks[0]; k++)
        if (strcmp(nm, blocks[k]) == 0) return 1;
    return 0;
}

static void entity(Out *o, const char *e, int len) {
    if (len >= 2 && e[0] == '#') {
        uint32_t cp = 0;
        if (e[1] == 'x' || e[1] == 'X') {
            for (int i = 2; i < len; i++) {
                int v = hexv((unsigned char)e[i]);
                if (v < 0) return;
                cp = cp * 16 + (uint32_t)v;
            }
        } else {
            for (int i = 1; i < len; i++) {
                if (e[i] < '0' || e[i] > '9') return;
                cp = cp * 10 + (uint32_t)(e[i] - '0');
            }
        }
        if (cp == 0xA0) cp = ' ';
        if (cp > 0 && cp < 0x110000) put_cp(o, cp);
        return;
    }
    static const struct {
        const char *n;
        uint32_t cp;
    } tab[] = {{"amp", '&'}, {"lt", '<'}, {"gt", '>'}, {"quot", '"'}, {"apos", '\''}, {"nbsp", ' '},
               {"mdash", 0x2014}, {"ndash", 0x2013}, {"hellip", 0x2026}, {"lsquo", 0x2018}, {"rsquo", 0x2019},
               {"ldquo", 0x201C}, {"rdquo", 0x201D}, {"laquo", 0xAB}, {"raquo", 0xBB}, {"iexcl", 0xA1}, {"iquest", 0xBF},
               {"aacute", 0xE1}, {"eacute", 0xE9}, {"iacute", 0xED}, {"oacute", 0xF3}, {"uacute", 0xFA},
               {"Aacute", 0xC1}, {"Eacute", 0xC9}, {"Iacute", 0xCD}, {"Oacute", 0xD3}, {"Uacute", 0xDA},
               {"ntilde", 0xF1}, {"Ntilde", 0xD1}, {"uuml", 0xFC}, {"Uuml", 0xDC}, {"ccedil", 0xE7}, {"Ccedil", 0xC7},
               {"agrave", 0xE0}, {"egrave", 0xE8}, {"igrave", 0xEC}, {"ograve", 0xF2}, {"ugrave", 0xF9},
               {"acirc", 0xE2}, {"ecirc", 0xEA}, {"icirc", 0xEE}, {"ocirc", 0xF4}, {"ucirc", 0xFB},
               {"auml", 0xE4}, {"euml", 0xEB}, {"iuml", 0xEF}, {"ouml", 0xF6}, {"Auml", 0xC4}, {"Ouml", 0xD6},
               {"szlig", 0xDF}, {"bull", 0x2022}, {"copy", 0xA9}, {"deg", 0xB0}};
    for (size_t k = 0; k < sizeof tab / sizeof tab[0]; k++)
        if ((int)strlen(tab[k].n) == len && strncmp(tab[k].n, e, (size_t)len) == 0) {
            put_cp(o, tab[k].cp);
            return;
        }
}

static void html_to_text(const uint8_t *h, uint32_t n, Out *o) {
    uint32_t i = 0;
    while (i < n && !o->trunc) {
        uint8_t c = h[i];
        if (c == '<') {
            const char *t;
            int tl;
            uint32_t p = i;
            if (!next_tag((const char *)h, n, &p, &t, &tl)) break;
            char name[16];
            tag_name(t, tl, name, sizeof name);
            int selfclose = tl > 0 && t[tl - 1] == '/';
            i = p;
            if (name[0] != '/' && !selfclose &&
                (!strcmp(name, "head") || !strcmp(name, "script") || !strcmp(name, "style"))) {
                char endtag[24];
                snprintf(endtag, sizeof endtag, "</%s", name);
                i = find_ci(h, n, i, endtag);
                while (i < n && h[i] != '>') i++;
                i++;
                continue;
            }
            if (is_block(name)) out_put(o, '\n');
            continue;
        }
        if (c == '&') {
            uint32_t e = i + 1;
            while (e < n && e - i <= 10 && h[e] != ';' && h[e] != ' ' && h[e] != '<') e++;
            if (e < n && h[e] == ';') {
                entity(o, (const char *)h + i + 1, (int)(e - i - 1));
                i = e + 1;
                continue;
            }
        }
        out_put(o, c);
        i++;
    }
    out_put(o, '\n');
    out_put(o, '\n');
}

/* ================================================================= epub */

typedef struct {
    char id[48];
    const char *tag;
    int tl;
} Item;

#define MAXITEMS 1024
#define MAXSPINE 1024

int epub_load(const char *path, unsigned char **outbuf, uint32_t *outlen, uint32_t maxlen, int *truncated) {
    Zip z;
    int ok = 0;
    uint8_t *cont = NULL, *opf = NULL;
    Item *items = NULL;
    char (*spine)[48] = NULL;
    Out o;
    memset(&o, 0, sizeof o);
    o.max = maxlen;
    *truncated = 0;

    if (!zip_open(&z, path)) return 0;

    uint32_t sz = 0;
    ZEnt *e = zip_find(&z, "META-INF/container.xml");
    if (!e) goto done;
    cont = zip_read(&z, e, &sz);
    if (!cont) goto done;

    char opfpath[320] = "";
    {
        uint32_t pos = 0;
        const char *t;
        int tl;
        while (next_tag((const char *)cont, sz, &pos, &t, &tl)) {
            char nm[24];
            tag_name(t, tl, nm, sizeof nm);
            if (!strcmp(nm, "rootfile")) {
                char fp[300];
                if (attr(t, tl, "full-path", fp, sizeof fp)) {
                    resolve("", fp, opfpath, sizeof opfpath);
                    break;
                }
            }
        }
    }
    if (!opfpath[0]) goto done;

    e = zip_find(&z, opfpath);
    if (!e) goto done;
    uint32_t osz = 0;
    opf = zip_read(&z, e, &osz);
    if (!opf) goto done;

    char base[320];
    snprintf(base, sizeof base, "%s", opfpath);
    {
        char *sl = strrchr(base, '/');
        if (sl) sl[1] = 0;
        else base[0] = 0;
    }

    items = (Item *)malloc(sizeof(Item) * MAXITEMS);
    spine = (char(*)[48])malloc(48 * MAXSPINE);
    if (!items || !spine) goto done;
    int nitems = 0, nspine = 0;
    {
        uint32_t pos = 0;
        const char *t;
        int tl;
        while (next_tag((const char *)opf, osz, &pos, &t, &tl)) {
            char nm[24];
            tag_name(t, tl, nm, sizeof nm);
            if (!strcmp(nm, "item") && nitems < MAXITEMS) {
                char mt[64];
                int has = attr(t, tl, "media-type", mt, sizeof mt);
                if (has && !strstr(mt, "html")) continue;
                if (!attr(t, tl, "id", items[nitems].id, sizeof items[nitems].id)) continue;
                items[nitems].tag = t;
                items[nitems].tl = tl;
                nitems++;
            } else if (!strcmp(nm, "itemref") && nspine < MAXSPINE) {
                if (attr(t, tl, "idref", spine[nspine], 48)) nspine++;
            }
        }
    }

    int count = nspine ? nspine : nitems;
    for (int s = 0; s < count && !o.trunc; s++) {
        const Item *it = NULL;
        if (nspine) {
            for (int k = 0; k < nitems; k++)
                if (strcmp(items[k].id, spine[s]) == 0) {
                    it = &items[k];
                    break;
                }
        } else {
            it = &items[s];
        }
        if (!it) continue;
        char href[260], full[320];
        if (!attr(it->tag, it->tl, "href", href, sizeof href)) continue;
        resolve(base, href, full, sizeof full);
        ZEnt *ce = zip_find(&z, full);
        if (!ce) continue;
        uint32_t csz = 0;
        uint8_t *ch = zip_read(&z, ce, &csz);
        if (!ch) continue;
        html_to_text(ch, csz, &o);
        free(ch);
    }

    if (o.n > 0) {
        *outbuf = o.d;
        *outlen = o.n;
        *truncated = o.trunc;
        ok = 1;
        o.d = NULL;
    }

done:
    free(o.d);
    free(cont);
    free(opf);
    free(items);
    free(spine);
    zip_close(&z);
    return ok;
}
